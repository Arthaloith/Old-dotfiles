# tmux-cssh plugin

This plugin adds autocompletion for [`tmux-cssh`](https://github.com/zinic/tmux-cssh/).

To use it, add `tmux-cssh` to the plugins array in your zshrc file:
```zsh
plugins=(... tmux-cssh)
```

First upstream repo, now disappeared: https://github.com/dennishafemann/tmux-cssh.
