# Homestead

This plugin provides completion for [Homestead](https://laravel.com/docs/homestead).

To use it add homestead to the plugins array in your zshrc file.

```bash
plugins=(... homestead)
```
